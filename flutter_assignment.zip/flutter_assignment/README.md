# TaskFlow — Flutter Internship Assignment (Weeks 1–3)

![Flutter](https://img.shields.io/badge/Flutter-3.x-blue?logo=flutter)
![Dart](https://img.shields.io/badge/Dart-3.x-blue?logo=dart)
![SharedPreferences](https://img.shields.io/badge/SharedPreferences-2.2.2-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

A complete Flutter Task Management application built as part of a 3-week internship program. The app demonstrates core Flutter concepts including UI building, navigation, state management, and local data persistence.

---

## 📱 App Demo

The app includes:
- **Splash Screen** → **Login Screen** → **Home (Task Manager)** + **Counter Screen**

---

## ✅ Features by Week

### Week 1 — Basic Flutter & UI
- ✅ Login screen with `TextFormField` for email and password
- ✅ Email format validation with regex
- ✅ Password non-empty + minimum length validation
- ✅ "Forgot Password?" dialog via `TextButton`
- ✅ UI structured with `Column`, `Row`, `Container`, `Form`
- ✅ Navigation from Login → Home using `Navigator.pushReplacement()`

### Week 2 — State Management & Persistent Storage
- ✅ Counter app using `setState`
- ✅ Increment / Decrement / Reset counter
- ✅ Counter value saved with `SharedPreferences` (persists on restart)
- ✅ To-do task list with Add, Display (`ListView`), and persistence

### Week 3 — Final Task Management App
- ✅ Home screen displaying a list of tasks
- ✅ Add tasks via bottom sheet dialog
- ✅ Delete tasks (tap button or swipe to dismiss)
- ✅ Mark tasks as complete (animated checkbox)
- ✅ Filter tasks: All / Active / Completed
- ✅ Progress bar showing completion percentage
- ✅ Data persistence using `SharedPreferences`
- ✅ Custom `AppBar` with title and action buttons (Icons library)
- ✅ Clear completed tasks action

### Bonus
- ✅ Animated **Splash Screen**
- ✅ Session persistence (auto-login if previously logged in)
- ✅ Swipe-to-delete with Dismissible widget
- ✅ Gradient UI and polished Material 3 design

---

## 🗂️ Project Structure

```
lib/
├── main.dart                  # App entry point & theme
├── models/
│   └── task.dart              # Task data model with JSON serialization
├── services/
│   └── storage_service.dart   # SharedPreferences wrapper (tasks, counter, auth)
└── screens/
    ├── splash_screen.dart     # Animated splash with auto-navigation
    ├── login_screen.dart      # Login with form validation (Week 1)
    ├── home_screen.dart       # Task manager — add/delete/complete (Week 3)
    └── counter_screen.dart    # Counter with persistence (Week 2)
```

---

## 🚀 Setup Instructions

### Prerequisites
- Flutter SDK `>=3.0.0` — [Install Flutter](https://flutter.dev/docs/get-started/install)
- Android Studio or VS Code with Flutter/Dart plugins
- Android Emulator or physical device (Android/iOS)

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/<your-username>/flutter_assignment.git
cd flutter_assignment

# 2. Install dependencies
flutter pub get

# 3. Run the app
flutter run
```

### Build APK (Android)
```bash
flutter build apk --release
```
The APK will be at `build/app/outputs/flutter-apk/app-release.apk`

---

## 📦 Dependencies

| Package | Version | Purpose |
|---|---|---|
| `shared_preferences` | ^2.2.2 | Local key-value storage |
| `cupertino_icons` | ^1.0.6 | iOS-style icons |

---

## 🎨 Screens Overview

| Screen | Description |
|---|---|
| Splash Screen | Animated logo, checks login state, auto-navigates |
| Login Screen | Email + password fields, validation, forgot password |
| Home Screen | Task list with filters, progress bar, FAB to add tasks |
| Counter Screen | Increment/decrement counter, value persists across restarts |

---

## 🧪 Testing the App

1. **Login**: Enter any valid email (e.g., `test@example.com`) and any password with 6+ characters
2. **Add Tasks**: Tap the `+ Add Task` button at the bottom
3. **Complete Tasks**: Tap the circle checkbox next to a task
4. **Delete Tasks**: Tap the trash icon or swipe left on a task
5. **Counter**: Tap the timer icon ⏱ in the app bar to visit the counter
6. **Logout**: Tap the logout icon in the top-right corner
7. **Persistence**: Close and reopen the app — all tasks and counter value are saved

---

## 🛠️ Debugging Tips

- Use `flutter logs` to view console output
- Use `flutter analyze` to catch lint errors
- Use Flutter DevTools: run `flutter pub global activate devtools` then `devtools`
- For SharedPreferences issues, ensure `flutter pub get` ran successfully

---

## 📁 Key Implementation Notes

### Form Validation (Week 1)
```dart
String? _validateEmail(String? value) {
  final emailRegex = RegExp(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$');
  if (!emailRegex.hasMatch(value?.trim() ?? '')) return 'Enter a valid email';
  return null;
}
```

### Saving Data with SharedPreferences (Week 2 & 3)
```dart
// Save tasks
final prefs = await SharedPreferences.getInstance();
await prefs.setString('tasks', json.encode(tasks.map((t) => t.toMap()).toList()));

// Load tasks
final String? tasksJson = prefs.getString('tasks');
final List<Task> tasks = json.decode(tasksJson!).map((e) => Task.fromMap(e)).toList();
```

### Navigation (Week 1)
```dart
Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LoginScreen()));
```

---

## 👤 Author

**[Your Name]**  
Flutter Internship — Weeks 1–3  
Deadline: 23rd March, 2026

---

## 📄 License

This project is for educational/internship purposes.
