import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_assignment/main.dart';

void main() {
  testWidgets('App launches and shows SplashScreen', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());
    // Splash screen should be visible initially
    expect(find.text('TaskFlow'), findsOneWidget);
  });
}
